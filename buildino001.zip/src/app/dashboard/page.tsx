'use client';
import { useState } from 'react';
import Sidebar from '@/components/Sidebar';
import Header from '@/components/Header';
import DashboardCard from '@/components/DashboardCard';
import ChartCard from '@/components/ChartCard';

export default function DashboardPage() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div
      className="flex min-h-screen transition-colors duration-300"
      style={{
        backgroundColor: 'var(--bg-color)',
        color: 'var(--text-color)'
      }}
    >
      {/* Sidebar Desktop */}
      <div className="hidden md:block">
        <Sidebar />
      </div>

      {/* Mobile Backdrop */}
      {menuOpen && (
        <div
          //className="fixed inset-0 z-40 transition-colors duration-300"
className="fixed inset-0 bg-black bg-opacity-40 z-40 transition-opacity duration-300"
    onClick={() => setMenuOpen(false)}          style={{
            backgroundColor: 'var(--bg-secondary)',
            borderColor: 'var(--border-color)',
            opacity: 0.6
          }}
          onClick={() => setMenuOpen(false)}
        ></div>
      )}

      {/* Sidebar Mobile */}
      <div
        // className={`fixed top-0 right-0 h-full w-64 transform transition-transform duration-300 z-50 ${
        //   menuOpen ? 'translate-x-0' : 'translate-x-full'
        // }`}
   className={`fixed top-0 right-0 h-full w-64 bg-[var(--bg-secondary)] shadow-lg z-50 transform transition-transform duration-300 ease-in-out ${
    menuOpen ? "translate-x-0" : "translate-x-full"
  }`}
        style={{
          backgroundColor: 'var(--bg-secondary)',
          color: 'var(--text-color)',
          borderLeft: `1px solid var(--border-color)`
        }}
      >
        <Sidebar mobile onClose={() => setMenuOpen(false)} />
      </div>

      {/* Main */}
      <div className="flex-1 p-6">
        <Header onMenu={() => setMenuOpen(true)} />

        {/* Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <DashboardCard title="مجموع واحدها" value="24" />
          <DashboardCard title="ساکنین ثبت‌شده" value="56" />
          <DashboardCard title="موجودی صندوق" value="۵,۳۰۰,۰۰۰ تومان" />
          <DashboardCard title="پرداخت‌های معوقه" value="5" />
          <DashboardCard title="میانگین پرداخت" value="۳۵۰,۰۰۰ تومان" />
          <ChartCard />
        </div>
      </div>
    </div>
  );
}
