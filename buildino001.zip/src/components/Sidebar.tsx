'use client';
import { HomeIcon, BuildingOfficeIcon, ChartBarIcon } from '@heroicons/react/24/outline';

interface SidebarProps {
  mobile?: boolean;
  onClose?: () => void;
  open?: boolean;
}

export default function Sidebar({
  mobile = false,
  onClose,
  open = false
}: SidebarProps) {
  const items = [
    { label: 'داشبورد', icon: HomeIcon },
    { label: 'مدیریت واحدها', icon: BuildingOfficeIcon },
    { label: 'گزارش‌ها', icon: ChartBarIcon },
  ];

  return (
    <>
      {/* بک‌دراپ موبایل */}
      {mobile && (
        <div
          className={`fixed inset-0 bg-black bg-opacity-40 z-40 transition-opacity duration-300 ${
            open ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
          }`}
          onClick={onClose}
        />
      )}

      {/* سایدبار */}
      <aside
        className={`h-full w-64 p-6 transition-colors duration-300
          ${mobile
            ? `fixed top-0 right-0 z-50 transform transition-transform duration-300 ease-in-out ${
                open ? 'translate-x-0' : 'translate-x-full'
              } backdrop-blur-lg`
            : ''
          }
        `}
        style={{
          backgroundColor: 'var(--bg-secondary)',
          color: 'var(--text-color)',
          borderRight: `1px solid var(--border-color)`,
          boxShadow: '4px 4px 20px var(--shadow-light), -4px -4px 20px var(--shadow-dark)'
        }}
      >
        <h2
          className="text-lg font-bold mb-6"
          style={{ color: 'var(--accent-color)' }}
        >
          منوی اصلی
        </h2>

        <nav className="space-y-3">
          {items.map((item, i) => (
            <button
              key={i}
              className="flex items-center justify-end w-full gap-3 py-2 px-4 rounded-xl transition hover:opacity-80"
              onClick={onClose}
              style={{
                backgroundColor: 'transparent',
                color: 'var(--text-color)'
              }}
            >
              <span>{item.label}</span>
              <item.icon
                className="w-5 h-5"
                style={{ color: 'var(--accent-color)' }}
              />
            </button>
          ))}
        </nav>
      </aside>
    </>
  );
}
