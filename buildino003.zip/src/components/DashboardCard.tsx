import { motion } from 'framer-motion'; // F اضافه شد

// F اضافه شد: تعریف حالت‌های مختلف انیمیشن برای کارت
const cardVariants = {
  hidden: { opacity: 0, y: 20 }, // حالت اولیه: شفاف و کمی پایین‌تر
  visible: {
    opacity: 1,
    y: 0, // حالت نهایی: کاملا پیدا و در جای اصلی
    transition: { duration: 0.4, ease: 'easeOut' },
  },
};

export default function DashboardCard({ title, value }: { title: string; value: string }) {
  return (
    // F تغییر یافت: div به motion.div تبدیل شد و variants به آن داده شد
    <motion.div
      variants={cardVariants}
      className="p-6 rounded-xl transform transition duration-300 hover:-translate-y-1 hover:scale-105 transition-colors"
      style={{
        backgroundColor: 'var(--bg-secondary)',
        color: 'var(--text-color)',
        boxShadow: '4px 4px 20px var(--shadow-light), -4px -4px 20px var(--shadow-dark)',
        border: '1px solid var(--border-color)',
      }}
    >
      <h3 className="font-bold mb-2" style={{ color: 'var(--accent-color)' }}>
        {title}
      </h3>
      <p className="text-2xl font-bold" style={{ color: 'var(--accent-color-light)' }}>
        {value}
      </p>
    </motion.div>
  );
}
