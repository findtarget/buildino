// src/app/ClientLayoutWrapper.tsx

'use client';

import { usePathname } from 'next/navigation';
import { ThemeProvider } from './context/ThemeContext';
import { SettingsProvider } from './context/SettingsContext'; // F اضافه کردن
import Sidebar from '@/components/Sidebar';
import Header from '@/components/Header';
import PageTransition from './page-transition';
import SettingsPanel from '@/components/SettingsPanel'; // F اضافه کردن

export default function ClientLayoutWrapper({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const noLayoutRoutes = ['/login'];

  if (noLayoutRoutes.includes(pathname)) {
    return <ThemeProvider>{children}</ThemeProvider>;
  }

  return (
    <ThemeProvider>
      <SettingsProvider> {/* F اضافه کردن Provider تنظیمات */}
        <div className="flex h-screen" style={{ backgroundColor: 'var(--bg-color)' }}>
          <Sidebar />
          <div className="flex-1 flex flex-col overflow-hidden">
            <Header />
            <main className="flex-1 overflow-x-hidden overflow-y-auto">
                <PageTransition>{children}</PageTransition>
            </main>
          </div>
          <SettingsPanel /> {/* F اضافه کردن پنل تنظیمات در اینجا */}
        </div>
      </SettingsProvider>
    </ThemeProvider>
  );
}
