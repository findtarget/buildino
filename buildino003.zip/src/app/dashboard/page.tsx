'use client';
import { useState } from 'react';
import DashboardCard from '@/components/DashboardCard';
import ChartCard from '@/components/ChartCard';
import { motion } from 'framer-motion'; // F اضافه شد

export default function DashboardPage() {
  const [menuOpen, setMenuOpen] = useState(false);

  // F اضافه شد: متغیر برای کنترل انیمیشن کانتینر
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1, // تاخیر 0.1 ثانیه بین انیمیشن هر کارت
      },
    },
  };

  return (
    <div
      className="flex min-h-screen transition-colors duration-300"
      style={{
        backgroundColor: 'var(--bg-color)',
        color: 'var(--text-color)',
      }}
    >
      {/* Sidebar Desktop */}
      <div className="hidden md:block">
      </div>

      {/* Mobile Backdrop */}
      {menuOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-40 z-40 transition-opacity duration-300"
          onClick={() => setMenuOpen(false)}
        ></div>
      )}

      {/* Sidebar Mobile */}
      <div
        className={`fixed top-0 right-0 h-full w-64 bg-[var(--bg-secondary)] shadow-lg z-50 transform transition-transform duration-300 ease-in-out ${
          menuOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
        style={{
          backgroundColor: 'var(--bg-secondary)',
          color: 'var(--text-color)',
          borderLeft: `1px solid var(--border-color)`,
        }}
      >
      </div>

      {/* Main */}
      <div className="flex-1 p-6">

        {/* Cards */}
        {/* F تغییر یافت: div به motion.div تبدیل و تنظیمات انیمیشن به آن اعمال شد */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          <DashboardCard title="مجموع واحدها" value="24" />
          <DashboardCard title="ساکنین ثبت‌شده" value="56" />
          <DashboardCard title="موجودی صندوق" value="۵,۳۰۰,۰۰۰ تومان" />
          <DashboardCard title="پرداخت‌های معوقه" value="5" />
          <DashboardCard title="میانگین پرداخت" value="۳۵۰,۰۰۰ تومان" />
          <ChartCard />
        </motion.div>
      </div>
    </div>
  );
}
