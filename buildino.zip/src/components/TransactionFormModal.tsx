// src/components/TransactionFormModal.tsx
'use client';

import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Transaction } from '@/types/index.d';
import { toPersianDigits, formatJalaliDate, parseJalaliDate } from '@/lib/utils';
import dynamic from 'next/dynamic';

const CustomDatePicker = dynamic(() => import('@/components/CustomDatePicker'), { ssr: false });

interface UnitInfo {
  id: number;
  unitNumber: string;
}

type TransactionFormData = Omit<Transaction, 'id' | 'date' | 'amount'> & {
  date: Date | null;
  amount: string;
};

interface TransactionFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: Omit<Transaction, 'id'>) => void;
  initialData: Transaction | null;
  transactionType: 'Income' | 'Expense';
  unitsList: UnitInfo[];
}

const expenseCategories = ['Repairs', 'Utilities', 'Salaries', 'Cleaning', 'Miscellaneous'];
const incomeCategories = ['MonthlyCharge', 'ParkingRental', 'MiscellaneousIncome'];
const categoryTranslations: { [key: string]: string } = {
  Repairs: 'تعمیرات و نگهداری', Utilities: 'هزینه قبوض و مشاعات', Salaries: 'حقوق و دستمزد', Cleaning: 'نظافت', Miscellaneous: 'هزینه‌های متفرقه',
  MonthlyCharge: 'شارژ ماهانه', ParkingRental: 'درآمد اجاره پارکینگ', MiscellaneousIncome: 'درآمد متفرقه'
};

export default function TransactionFormModal({
  isOpen, onClose, onSubmit, initialData, transactionType, unitsList,
}: TransactionFormModalProps) {
  const [formData, setFormData] = useState<TransactionFormData>({
    title: '', amount: '', type: transactionType, category: transactionType === 'Income' ? 'MonthlyCharge' : 'Repairs', date: new Date(),
    relatedUnitId: undefined, isCharge: false, description: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (isOpen) {
      setErrors({});
      if (initialData) {
        setFormData({
          ...initialData,
          amount: String(initialData.amount),
          relatedUnitId: initialData.relatedUnitId ?? undefined,
          date: initialData.date ? parseJalaliDate(initialData.date) : null,
        });
      } else {
        setFormData({
          title: '', amount: '', type: transactionType, category: transactionType === 'Income' ? 'MonthlyCharge' : 'Repairs',
          date: new Date(), relatedUnitId: undefined, isCharge: false, description: '',
        });
      }
    }
  }, [isOpen, initialData, transactionType]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handleDateChange = (date: Date | undefined) => {
    setFormData(prev => ({ ...prev, date: date || null }));
    if (errors.date) {
      setErrors(prev => ({ ...prev, date: '' }));
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.title.trim()) newErrors.title = 'عنوان تراکنش نمی‌تواند خالی باشد.';
    if (!formData.amount || parseFloat(formData.amount) <= 0) newErrors.amount = 'مبلغ باید یک عدد مثبت باشد.';
    if (!formData.date) newErrors.date = 'انتخاب تاریخ الزامی است.';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;
    onSubmit({
      ...formData,
      amount: parseFloat(formData.amount) || 0,
      relatedUnitId: formData.relatedUnitId ? parseInt(String(formData.relatedUnitId)) : undefined,
      date: formData.date ? formatJalaliDate(formData.date) : '',
    });
    onClose();
  };

  const modalTitle = `${initialData ? 'ویرایش' : 'ثبت'} ${transactionType === 'Income' ? 'درآمد' : 'هزینه'}`;
  const submitButtonClass = transactionType === 'Income' ? 'bg-emerald-500 hover:bg-emerald-600' : 'bg-rose-500 hover:bg-rose-600';
  const categories = transactionType === 'Income' ? incomeCategories : expenseCategories;

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        >
          <motion.div
            onClick={(e) => e.stopPropagation()}
            initial={{ y: -50, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: -50, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 300, damping: 25 }}
            className="w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6 rounded-2xl relative"
            style={{ backgroundColor: 'var(--bg-secondary)', border: '1px solid var(--border-color)' }}
          >
            <h2 className="text-xl font-bold mb-6 text-right" style={{ color: 'var(--accent-color)' }}>{modalTitle}</h2>
            <form onSubmit={handleSubmit} className="space-y-4 text-right" noValidate>
              <div>
                <input name="title" value={formData.title} onChange={handleChange} placeholder="عنوان تراکنش" className="p-2 w-full rounded-lg bg-[var(--bg-color)] border border-[var(--border-color)] text-[var(--text-color)]" />
                {errors.title && <p className="text-rose-500 text-xs mt-1 text-right">{errors.title}</p>}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <input name="amount" type="number" value={formData.amount} onChange={handleChange} placeholder="مبلغ (به تومان)" className="p-2 w-full rounded-lg bg-[var(--bg-color)] border border-[var(--border-color)] text-[var(--text-color)]" />
                    {errors.amount && <p className="text-rose-500 text-xs mt-1 text-right">{errors.amount}</p>}
                </div>
                <div>
                    <CustomDatePicker value={formData.date} onChange={handleDateChange} placeholder="تاریخ تراکنش" />
                    {errors.date && <p className="text-rose-500 text-xs mt-1 text-right">{errors.date}</p>}
                </div>
                <select name="category" value={formData.category} onChange={handleChange} className="p-2 rounded-lg bg-[var(--bg-color)] border border-[var(--border-color)] text-[var(--text-color)]">
                  {categories.map(cat => <option key={cat} value={cat}>{categoryTranslations[cat]}</option>)}
                </select>
                <select name="relatedUnitId" value={String(formData.relatedUnitId || '')} onChange={handleChange} className="p-2 rounded-lg bg-[var(--bg-color)] border border-[var(--border-color)] text-[var(--text-color)]">
                  <option value="">واحد مرتبط (اختیاری)</option>
                  {unitsList.map((unit) => <option key={unit.id} value={unit.id}>واحد {toPersianDigits(unit.unitNumber)}</option>)}
                </select>
              </div>

              <textarea name="description" value={formData.description || ''} onChange={handleChange} placeholder="توضیحات (اختیاری)" rows={3} className="p-2 w-full rounded-lg bg-[var(--bg-color)] border border-[var(--border-color)] text-[var(--text-color)]"></textarea>

              <div className="pt-4 flex justify-end gap-3">
                <button type="button" onClick={onClose} className="px-4 py-2 rounded-lg transition-colors" style={{backgroundColor: 'var(--bg-color)', border: '1px solid var(--border-color)', color: 'var(--text-color)'}}>انصراف</button>
                <button type="submit" className={`px-6 py-2 rounded-lg text-white font-semibold transition-transform duration-200 hover:scale-105 ${submitButtonClass}`}>ذخیره</button>
              </div>
            </form>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
