// src/components/AnalyticsDashboard.tsx
'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Line, Bar, Doughnut } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler
} from 'chart.js';
import { AnalyticsMetrics } from '@/types/reports';
import { toPersianDigits, formatCurrency } from '@/lib/utils';
import {
  BanknotesIcon,
  ArrowTrendingUpIcon,
  ArrowTrendingDownIcon,
  ChartBarIcon,
  HomeIcon,
  CalendarDaysIcon,
  ClockIcon
} from '@heroicons/react/24/outline';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

interface AnalyticsDashboardProps {
  metrics: AnalyticsMetrics;
  loading?: boolean;
  dateRange: { from: string; to: string };
  onDateRangeChange: (range: { from: string; to: string }) => void;
}

const chartOptions = {
  responsive: true,
  plugins: {
    legend: {
      position: 'top' as const,
    },
    title: {
      display: true,
    },
  },
  scales: {
    y: {
      beginAtZero: true,
    },
  },
};

export default function AnalyticsDashboard({
  metrics,
  loading = false,
  dateRange,
  onDateRangeChange
}: AnalyticsDashboardProps) {
  const [selectedPeriod, setSelectedPeriod] = useState<'week' | 'month' | 'quarter' | 'year'>('month');
  const [comparisonMode, setComparisonMode] = useState<'previous' | 'year'>('previous');

  // >>>>>>>>>> بخش اصلاح شده برای جلوگیری از خطا <<<<<<<<<<
  // با اضافه کردن مقادیر پیش‌فرض (?? 0)، از خطای toFixed روی undefined جلوگیری می‌کنیم
  const kpiCards = [
    {
      title: 'کل درآمد',
      value: formatCurrency(metrics.totalRevenue),
      change: metrics.monthlyGrowth?.net ?? 0,
      changeText: `${toPersianDigits(Math.abs(metrics.monthlyGrowth?.net ?? 0).toFixed(1))}%`,
      icon: BanknotesIcon,
      color: 'emerald',
      trend: (metrics.monthlyGrowth?.net ?? 0) >= 0 ? 'up' : 'down'
    },
    {
      title: 'کل هزینه‌ها',
      value: formatCurrency(metrics.totalExpenses),
      change: -2.1, // Placeholder
      changeText: '۲.۱%',
      icon: ArrowTrendingDownIcon,
      color: 'rose',
      trend: 'down'
    },
    {
      title: 'درآمد خالص',
      value: formatCurrency(metrics.netIncome),
      change: metrics.profitMargin ?? 0,
      changeText: `${toPersianDigits((metrics.profitMargin ?? 0).toFixed(1))}%`,
      icon: ArrowTrendingUpIcon,
      color: metrics.netIncome >= 0 ? 'emerald' : 'rose',
      trend: metrics.netIncome >= 0 ? 'up' : 'down'
    },
    {
      title: 'تعداد واحدها',
      value: toPersianDigits('24'),
      change: 0,
      changeText: '۰%',
      icon: HomeIcon,
      color: 'blue',
      trend: 'neutral'
    },
    {
      title: 'نرخ اشغال',
      value: `${toPersianDigits((metrics.unitOccupancyRate ?? 0).toFixed(1))}%`,
      change: 2.3, // Placeholder
      changeText: '۲.۳%',
      icon: ChartBarIcon,
      color: 'purple',
      trend: 'up'
    },
    {
      title: 'نرخ وصولی',
      value: `${toPersianDigits((metrics.collectionRate ?? 0).toFixed(1))}%`,
      change: 1.8, // Placeholder
      changeText: '۱.۸%',
      icon: CalendarDaysIcon,
      color: 'indigo',
      trend: 'up'
    }
  ];

  // Monthly Trends Chart Data
  // >>>>>>>>>> نام متغیر از monthlyTrends به monthlyData تغییر کرد <<<<<<<<<<
  const monthlyTrendsData = {
    labels: metrics.monthlyData.map(t => t.month),
    datasets: [
      {
        label: 'درآمد',
        data: metrics.monthlyData.map(t => t.income),
        borderColor: 'rgb(16, 185, 129)',
        backgroundColor: 'rgba(16, 185, 129, 0.1)',
        fill: true,
        tension: 0.4,
      },
      {
        label: 'هزینه',
        data: metrics.monthlyData.map(t => t.expense),
        borderColor: 'rgb(239, 68, 68)',
        backgroundColor: 'rgba(239, 68, 68, 0.1)',
        fill: true,
        tension: 0.4,
      },
      {
        label: 'خالص',
        data: metrics.monthlyData.map(t => t.net),
        borderColor: 'rgb(59, 130, 246)',
        backgroundColor: 'rgba(59, 130, 246, 0.1)',
        fill: true,
        tension: 0.4,
      }
    ],
  };
  // >>>>>>>>>> پایان بخش اصلاح شده <<<<<<<<<<

  // Expense Categories Chart
  const expenseCategoriesData = {
    labels: metrics.topExpenseCategories.map(c => c.category),
    datasets: [
      {
        data: metrics.topExpenseCategories.map(c => c.amount),
        backgroundColor: [
          'rgba(239, 68, 68, 0.8)',
          'rgba(245, 158, 11, 0.8)',
          'rgba(16, 185, 129, 0.8)',
          'rgba(59, 130, 246, 0.8)',
          'rgba(139, 92, 246, 0.8)',
        ],
        borderColor: [
          'rgba(239, 68, 68, 1)',
          'rgba(245, 158, 11, 1)',
          'rgba(16, 185, 129, 1)',
          'rgba(59, 130, 246, 1)',
          'rgba(139, 92, 246, 1)',
        ],
        borderWidth: 2,
      },
    ],
  };
    // بقیه کد بدون تغییر باقی می‌ماند...
    // ...
}
