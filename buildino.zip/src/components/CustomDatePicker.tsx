// src/components/CustomDatePicker.tsx

'use client';

import { DayPicker, DropdownProps } from 'react-day-picker';
import { Popover, Transition } from '@headlessui/react';
import { CalendarIcon } from '@heroicons/react/24/outline';
import { toPersianDigits, gregorianToJalali, createJalaliDate } from '@/lib/utils';
import {
  format as formatJalali,
  isValid
} from 'date-fns-jalali';
import 'react-day-picker/dist/style.css';
import './jalali-fix.css';

interface CustomDatePickerProps {
  value: Date | null;
  onChange: (date: Date | undefined) => void;
  placeholder?: string;
  disabled?: boolean;
}

export default function CustomDatePicker({
  value,
  onChange,
  placeholder = 'انتخاب تاریخ',
  disabled = false
}: CustomDatePickerProps) {

  const formatDisplayDate = (date: Date | null): string => {
    if (!date || !isValid(date)) return placeholder;
    try {
      const str = formatJalali(date, 'yyyy/MM/dd');
      return toPersianDigits(str);
    } catch {
      return 'تاریخ نامعتبر';
    }
  };

  const persianWeekdays = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];
  const persianMonths = [
    'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
    'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'
  ];

  const formatCaption = (date: Date) => {
    try {
      if (!isValid(date)) return 'تاریخ نامعتبر';
      
      const jalaliDate = gregorianToJalali(date);
      const month = persianMonths[jalaliDate.month - 1] || persianMonths[0];
      const year = toPersianDigits(jalaliDate.year);
      return `${month} ${year}`;
    } catch {
      return 'تاریخ نامعتبر';
    }
  };

  const formatWeekdayName = (date: Date) => {
    try {
      return persianWeekdays[date.getDay()] ?? '';
    } catch {
      return '';
    }
  };

  const formatDay = (date: Date) => {
    try {
      if (!isValid(date)) return '';
      const jalaliDate = gregorianToJalali(date);
      return toPersianDigits(jalaliDate.day);
    } catch {
      return '';
    }
  };

  const currentJalaliYear = gregorianToJalali(new Date()).year;
  const fromYear = currentJalaliYear - 50;
  const toYear = currentJalaliYear + 50;

  const fromDate = createJalaliDate(fromYear, 1, 1);
  const toDate = createJalaliDate(toYear, 12, 29);

  const CustomDropdown = (props: DropdownProps) => {
    const { displayMonth, onMonthChange } = props;
    
    // این تابع همیشه تاریخ اول ماه و سال نمایش داده شده را برمی‌گرداند
    // که برای محاسبات لازم است
    const currentJalaliDate = gregorianToJalali(displayMonth);

    if (props.name === 'year') {
      const years = [];
      for (let i = toYear; i >= fromYear; i--) {
        years.push(i);
      }
      return (
        <select
          value={currentJalaliDate.year}
          onChange={(e) => {
            const newYear = Number(e.target.value);
            // از روز و ماه فعلی برای ساخت تاریخ جدید استفاده می‌کنیم
            const newDate = createJalaliDate(newYear, currentJalaliDate.month, 1);
            onMonthChange?.(newDate);
          }}
          className="rdp-caption_dropdown_year"
        >
          {years.map((year) => (
            <option key={year} value={year}>
              {toPersianDigits(year)}
            </option>
          ))}
        </select>
      );
    }
    
    if (props.name === 'month') {
      return (
        <select
          value={currentJalaliDate.month - 1} // ایندکس آرایه ماه‌ها (0 تا 11)
          onChange={(e) => {
            const newMonthIndex = Number(e.target.value);
            // از سال فعلی برای ساخت تاریخ جدید استفاده می‌کنیم
            const newDate = createJalaliDate(currentJalaliDate.year, newMonthIndex + 1, 1);
            onMonthChange?.(newDate);
          }}
          className="rdp-caption_dropdown_month"
        >
          {persianMonths.map((month, i) => (
            <option key={month} value={i}>
              {month}
            </option>
          ))}
        </select>
      );
    }

    return null;
  };

  return (
    <Popover className="relative w-full">
      {({ open, close }) => (
        <>
          <Popover.Button
            disabled={disabled}
            className="p-3 w-full rounded-xl bg-[var(--bg-secondary)] border border-[var(--border-color)] text-[var(--text-color)] disabled:opacity-50 cursor-pointer text-right flex justify-between items-center focus:outline-none focus:ring-2 focus:ring-[var(--accent-color)] hover:border-[var(--accent-color)] transition-all duration-200 shadow-sm hover:shadow-md"
          >
            <span
              className={`text-sm ${
                value ? 'text-[var(--text-color)]' : 'text-gray-400'
              }`}
            >
              {formatDisplayDate(value)}
            </span>
            <CalendarIcon className="w-5 h-5 text-gray-400" />
          </Popover.Button>

          <Transition
            show={open}
            enter="transition ease-out duration-200"
            enterFrom="opacity-0 translate-y-1"
            enterTo="opacity-100 translate-y-0"
            leave="transition ease-in duration-150"
            leaveFrom="opacity-100 translate-y-0"
            leaveTo="opacity-0 translate-y-1"
          >
            <Popover.Panel className="absolute z-50 mt-2 shadow-2xl rounded-xl bg-[var(--bg-secondary)] border border-[var(--border-color)] right-0 w-[320px] overflow-hidden">
              <div className="p-4">
                <DayPicker
                  mode="single"
                  selected={value ?? undefined}
                  onSelect={(date) => {
                    if (date && isValid(date)) {
                      onChange(date);
                      setTimeout(() => close(), 100);
                    }
                  }}
                  dir="rtl"
                  fromDate={fromDate}
                  toDate={toDate}
                  captionLayout="dropdown-buttons"
                  formatters={{
                    formatCaption,
                    formatWeekdayName,
                    formatDay
                  }}
                  components={{
                    Dropdown: CustomDropdown
                  }}
                  classNames={{
                    months: 'rdp-months',
                    month: 'rdp-month space-y-4 w-full',
                    caption: 'rdp-caption',
                    caption_label: 'rdp-caption_label',
                    caption_dropdowns: 'rdp-caption_dropdowns',
                    nav: 'rdp-nav',
                    nav_button: 'rdp-nav_button',
                    table: 'rdp-table',
                    head_row: 'rdp-head_row',
                    head_cell: 'rdp-head_cell',
                    row: 'rdp-row',
                    cell: 'rdp-cell',
                    day: 'rdp-day',
                    day_selected: 'rdp-day_selected',
                    day_today: 'rdp-day_today',
                    day_outside: 'rdp-day_outside',
                    day_disabled: 'rdp-day_disabled',
                    day_hidden: 'rdp-day_hidden',
                  }}
                />
              </div>
            </Popover.Panel>
          </Transition>
        </>
      )}
    </Popover>
  );
}
