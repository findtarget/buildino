// src/lib/utils.ts
import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"
import { format, parse, isValid } from 'date-fns-jalali';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function toPersianDigits(s: string | number): string {
  const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return String(s).replace(/\d/g, (d) => persianDigits[parseInt(d)]);
}

export function toEnglishDigits(s: string): string {
  const englishDigits = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
  const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

  let result = s;
  for (let i = 0; i < persianDigits.length; i++) {
    result = result.replace(new RegExp(persianDigits[i], 'g'), englishDigits[i]);
  }
  return result;
}

export function formatCurrency(amount: number): string {
  const formatted = new Intl.NumberFormat('fa-IR').format(amount);
  return `${toPersianDigits(formatted)} تومان`;
}

export function formatJalaliDate(date: Date | string): string {
  try {
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    if (!isValid(dateObj)) {
      return "تاریخ نامعتبر";
    }
    return format(dateObj, 'yyyy/MM/dd');
  } catch (error) {
    console.error("Invalid date for formatJalaliDate:", date);
    return "تاریخ نامعتبر";
  }
}

export function parseJalaliDate(dateString: string): Date {
  try {
    // تبدیل اعداد فارسی به انگلیسی
    const englishDateString = toEnglishDigits(dateString.trim());
    
    // تلاش برای پارس کردن تاریخ شمسی
    const parsedDate = parse(englishDateString, 'yyyy/MM/dd', new Date());
    
    if (isValid(parsedDate)) {
      return parsedDate;
    }
    
    // اگر پارس نشد، تلاش دوباره با فرمت‌های مختلف
    const formats = ['yyyy/M/d', 'yyyy-MM-dd', 'yyyy-M-d'];
    for (const fmt of formats) {
      try {
        const testDate = parse(englishDateString, fmt, new Date());
        if (isValid(testDate)) {
          return testDate;
        }
      } catch {
        continue;
      }
    }
    
    throw new Error('Invalid date format');
  } catch (error) {
    console.error("Error parsing jalali date:", dateString, error);
    return new Date();
  }
}

// تابع جدید برای تبدیل تاریخ میلادی به شمسی
export function gregorianToJalali(date: Date): { year: number; month: number; day: number } {
  try {
    const formatted = format(date, 'yyyy/MM/dd');
    const [year, month, day] = formatted.split('/').map(Number);
    return { year, month, day };
  } catch {
    const now = new Date();
    const formatted = format(now, 'yyyy/MM/dd');
    const [year, month, day] = formatted.split('/').map(Number);
    return { year, month, day };
  }
}

// تابع جدید برای ساخت تاریخ از اجزای شمسی
export function createJalaliDate(year: number, month: number, day: number): Date {
  try {
    const dateString = `${year}/${month.toString().padStart(2, '0')}/${day.toString().padStart(2, '0')}`;
    return parse(dateString, 'yyyy/MM/dd', new Date());
  } catch {
    return new Date();
  }
}
