'use client';

import { useTheme } from '../context/ThemeContext';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { ArrowRightIcon, SunIcon, MoonIcon, SparklesIcon } from '@heroicons/react/24/solid';

export default function SettingsPage() {
  const { theme, setTheme } = useTheme();
  const router = useRouter();
  const [open, setOpen] = useState<string | null>('theme');

  const sections = [
    { id: 'theme', title: 'تغییر تم برنامه' },
    { id: 'profile', title: 'تنظیمات پروفایل' },
    { id: 'notifications', title: 'اعلان‌ها' },
  ];

  const themes = [
    { key: 'light', label: 'روشن', icon: SunIcon },
    { key: 'dark', label: 'تیره', icon: MoonIcon },
    { key: 'green', label: 'سبز', icon: SparklesIcon },
  ];

  return (
    <div style={{ backgroundColor: 'var(--bg-color)', color: 'var(--text-color)' }} className="min-h-screen p-6">

      {/* هدر برگشت */}
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-lg font-bold">تنظیمات</h1>
        <button
          onClick={() => router.push('/dashboard')}
          style={{
            backgroundColor: 'var(--bg-secondary)',
            border: `1px solid var(--border-color)`,
            color: 'var(--text-color)'
          }}
          className="w-10 h-10 flex items-center justify-center rounded-full shadow-md hover:opacity-80 transition"
        >
          <ArrowRightIcon className="w-5 h-5" />
        </button>
      </div>

      {/* آکاردئون‌ها */}
      <div className="space-y-4">
        {sections.map((section) => (
          <div
            key={section.id}
            style={{
              backgroundColor: 'var(--bg-secondary)',
              border: `1px solid var(--border-color)`,
              color: 'var(--text-color)'
            }}
            className="rounded-lg overflow-hidden"
          >
            <button
              onClick={() => setOpen(open === section.id ? null : section.id)}
              style={{ color: 'var(--accent-color)' }}
              className="w-full flex justify-between items-center px-4 py-3 font-bold"
            >
              {section.title}
              <span>{open === section.id ? '−' : '+'}</span>
            </button>

            {open === section.id && section.id === 'theme' && (
              <div className="p-4 space-y-3">
                {themes.map((opt) => {
                  const IconComponent = opt.icon;
                  return (
                    <button
                      key={opt.key}
                      onClick={() => setTheme(opt.key as any)}
                      style={{
                        backgroundColor:
                          theme === opt.key ? 'var(--accent-color)' : 'var(--bg-secondary)',
                        color: theme === opt.key ? '#fff' : 'var(--text-color)',
                        border: `1px solid var(--border-color)`
                      }}
                      className="w-full py-2 rounded-md transition hover:opacity-80 flex items-center justify-start gap-2 px-3"
                    >
                      <IconComponent className="w-5 h-5" />
                      {opt.label}
                    </button>
                  );
                })}
              </div>
            )}

            {open === section.id && section.id !== 'theme' && (
              <div className="p-4 text-sm text-gray-500 dark:text-gray-400">
                این بخش به زودی اضافه خواهد شد.
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
