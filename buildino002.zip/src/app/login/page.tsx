'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function LoginPage() {
  const router = useRouter();

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (username === 'admin' && password === '123456') {
      setError(null);
      router.push('/dashboard');
    } else {
      setError('نام کاربری یا رمز عبور اشتباه است.');
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-blue-50 to-blue-100">
      <div className="w-full max-w-xs p-8 rounded-2xl shadow-lg bg-white" style={{
        boxShadow: "4px 4px 20px #d2e3fa, -4px -4px 20px #ffffff"
      }}>
        <h2 className="text-2xl font-bold mb-6 text-blue-600 text-center tracking-tight">
          ورود به سامانه مدیریت ساختمان
        </h2>
        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-blue-800 mb-2">نام کاربری</label>
            <input
              type="text"
              className="w-full px-4 py-2 rounded-xl border-none outline-none bg-blue-50 focus:bg-white transition-all"
              style={{
                boxShadow: "inset 2px 2px 6px #c1d3ee, inset -2px -2px 6px #fff"
              }}
              placeholder="admin"
              value={username}
              onChange={e => setUsername(e.target.value)}
              autoFocus
            />
          </div>
          <div>
            <label className="block text-blue-800 mb-2">رمز عبور</label>
            <input
              type="password"
              className="w-full px-4 py-2 rounded-xl border-none outline-none bg-blue-50 focus:bg-white transition-all"
              style={{
                boxShadow: "inset 2px 2px 6px #c1d3ee, inset -2px -2px 6px #fff"
              }}
              placeholder="••••••"
              value={password}
              onChange={e => setPassword(e.target.value)}
            />
          </div>
          {error && (
            <div className="text-red-500 text-center text-sm">{error}</div>
          )}
          <button
            type="submit"
            className="w-full py-2 mt-2 rounded-xl bg-blue-500 text-white font-bold shadow-md hover:bg-blue-600 transition-all"
            style={{
              boxShadow: "2px 2px 14px #c4e1ff, -3px -3px 12px #fff"
            }}
          >
            ورود
          </button>
        </form>
      </div>
    </div>
  );
}
