// src/app/ClientLayoutWrapper.tsx
'use client';

import { useMediaQuery } from '@/hooks/useMediaQuery';
import Sidebar from '@/components/Sidebar';
import Header from '@/components/Header';
import { motion } from 'framer-motion';

export default function ClientLayoutWrapper({
  children,
}: {
  children: React.ReactNode;
}) {
  // تشخیص واقعی موبایل با ترکیب دو شرط
  const isMobileDevice = useMediaQuery('(max-width: 768px)');
  const isTabletOrDesktop = useMediaQuery('(min-width: 769px)');

  return (
    <div className="flex h-screen">
      {/* سایدبار دسکتاپ - فقط در تبلت و دسکتاپ نمایش داده شود */}
      {isTabletOrDesktop && <Sidebar />}

      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        <main className="flex-1 overflow-auto p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.4 }}
          >
            {children}
          </motion.div>
        </main>
      </div>
    </div>
  );
}
