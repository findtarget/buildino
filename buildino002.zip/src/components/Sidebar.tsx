'use client';
import { HomeIcon, BuildingOfficeIcon, ChartBarIcon } from '@heroicons/react/24/outline';
import { motion, AnimatePresence } from 'framer-motion';
import { useMediaQuery } from '@/hooks/useMediaQuery';

interface SidebarProps {
  mobile?: boolean;
  onClose?: () => void;
  open?: boolean;
}

export default function Sidebar({
  mobile = false,
  onClose,
  open = false
}: SidebarProps) {
  const items = [
    { label: 'داشبورد', icon: HomeIcon },
    { label: 'مدیریت واحدها', icon: BuildingOfficeIcon },
    { label: 'گزارش‌ها', icon: ChartBarIcon },
  ];

  // در صورتی که سایدبار دسکتاپ باشد ولی دستگاه موبایل باشد، نمایش نده
  const isMobileDevice = useMediaQuery('(max-width: 768px)');
  if (!mobile && isMobileDevice) {
    return null;
  }

  // سایدبار دسکتاپ
  if (!mobile) {
    return (
      <aside
        className="h-full w-64 p-6 transition-colors duration-300"
        style={{
          backgroundColor: 'var(--bg-secondary)',
          color: 'var(--text-color)',
          borderRight: `1px solid var(--border-color)`,
          boxShadow: '4px 4px 20px var(--shadow-light), -4px -4px 20px var(--shadow-dark)'
        }}
      >
        <h2
          className="text-lg font-bold mb-6"
          style={{ color: 'var(--accent-color)' }}
        >
          منوی اصلی
        </h2>

        <nav className="space-y-3">
          {items.map((item, i) => (
            <button
              key={i}
              className="flex items-center justify-end w-full gap-3 py-2 px-4 rounded-xl transition hover:opacity-80"
              style={{
                backgroundColor: 'transparent',
                color: 'var(--text-color)'
              }}
            >
              <span>{item.label}</span>
              <item.icon
                className="w-5 h-5"
                style={{ color: 'var(--accent-color)' }}
              />
            </button>
          ))}
        </nav>
      </aside>
    );
  }

  // سایدبار موبایل با انیمیشن
  return (
    <>
      {/* بک‌دراپ موبایل */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 bg-black bg-opacity-40 z-40"
            onClick={onClose}
          />
        )}
      </AnimatePresence>

      {/* سایدبار موبایل */}
      <AnimatePresence>
        {open && (
          <motion.aside
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            className="fixed top-0 right-0 z-50 h-full w-64 p-6 backdrop-blur-lg"
            style={{
              backgroundColor: 'var(--bg-secondary)',
              color: 'var(--text-color)',
              borderLeft: `1px solid var(--border-color)`,
              boxShadow: '4px 4px 20px var(--shadow-light), -4px -4px 20px var(--shadow-dark)'
            }}
          >
            <h2
              className="text-lg font-bold mb-6"
              style={{ color: 'var(--accent-color)' }}
            >
              منوی اصلی
            </h2>

            <nav className="space-y-3">
              {items.map((item, i) => (
                <button
                  key={i}
                  className="flex items-center justify-end w-full gap-3 py-2 px-4 rounded-xl transition hover:opacity-80"
                  onClick={onClose}
                  style={{
                    backgroundColor: 'transparent',
                    color: 'var(--text-color)'
                  }}
                >
                  <span>{item.label}</span>
                  <item.icon
                    className="w-5 h-5"
                    style={{ color: 'var(--accent-color)' }}
                  />
                </button>
              ))}
            </nav>
          </motion.aside>
        )}
      </AnimatePresence>
    </>
  );
}
