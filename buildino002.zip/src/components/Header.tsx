'use client';
import { useState } from 'react';
import { Bars3Icon, Cog6ToothIcon, ArrowLeftOnRectangleIcon } from '@heroicons/react/24/outline';
import { useRouter } from 'next/navigation';
import Sidebar from './Sidebar';
import { useMediaQuery } from '@/hooks/useMediaQuery';

export default function Header() {
  const router = useRouter();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const isMobile = useMediaQuery('(max-width: 768px)');

  return (
    <>
      {/* هدر */}
      <header
        className="w-full p-4 mb-6 rounded-xl flex justify-between items-center transition-colors duration-300"
        style={{
          backgroundColor: 'var(--bg-secondary)',
          color: 'var(--text-color)',
          boxShadow: '4px 4px 20px var(--shadow-light), -4px -4px 20px var(--shadow-dark)',
          border: '1px solid var(--border-color)'
        }}
      >
        <div className="flex items-center gap-4">
          {/* نمایش دکمه منو فقط در موبایل */}
          {isMobile && (
            <Bars3Icon
              className="w-7 h-7 cursor-pointer"
              style={{ color: 'var(--accent-color)' }}
              onClick={() => setSidebarOpen(true)}
            />
          )}
          <h1
            className="text-xl font-bold"
            style={{ color: 'var(--accent-color)' }}
          >
            داشبورد مدیریت ساختمان
          </h1>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => router.push('/settings')}
            className="p-2 rounded-full transition-colors"
            style={{
              backgroundColor: 'var(--accent-color-light)',
            }}
          >
            <Cog6ToothIcon className="w-6 h-6" style={{ color: 'var(--accent-color)' }} />
          </button>
          <img
            src="../../../user-avatar.jpg"
            className="w-8 h-8 rounded-full border"
            style={{ borderColor: 'var(--border-color)' }}
          />
          <button title="خروج"
            className="p-2 rounded-full text-white text-sm transition-colors"
            style={{
              backgroundColor: 'var(--accent-color)',
              boxShadow: '2px 2px 14px var(--shadow-light), -3px -3px 12px var(--shadow-dark)',
            }}
            onClick={() => router.push('/login')}
          >
            <ArrowLeftOnRectangleIcon className="w-6 h-6" />
          </button>
        </div>
      </header>

      {/* سایدبار موبایل - فقط در موبایل نمایش داده شود */}
      {isMobile && (
        <Sidebar
          mobile
          open={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
        />
      )}
    </>
  );
}
